export interface ChatMessage {
    username: String;
    text: String;    
    date: any;
}  