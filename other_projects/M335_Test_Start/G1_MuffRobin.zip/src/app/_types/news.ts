export class NewsMessage {
    date?: any;
    description?: string;
    imgurl?: string;
    slug?: string;
    titel?: string;
  }
  