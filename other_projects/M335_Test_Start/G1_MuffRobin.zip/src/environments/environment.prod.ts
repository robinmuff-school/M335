export const environment = {
  production: true,
  firebaseConfig: {
    // Hier einfügen
  }
};
