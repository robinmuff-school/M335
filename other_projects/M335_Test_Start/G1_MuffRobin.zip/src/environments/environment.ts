export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyAGfKXsiZDLvxPw_IdJVj6kkguumXRG-zc",
    authDomain: "m335-projekt.firebaseapp.com",
    databaseURL: "https://m335-projekt.firebaseio.com",
    projectId: "m335-projekt",
    storageBucket: "m335-projekt.appspot.com",
    messagingSenderId: "661342522206",
    appId: "1:661342522206:web:a119a60b993bbdea28ddcf"
  }
};